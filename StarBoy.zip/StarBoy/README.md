# STARBOY
StarBoy v1.1 (Kali Linux) - Metasploit automation

# Disclaimer:

 Usage of StarBoy for attacking targets without prior mutual consent is
 ILLEGAL. The Developer is not responsible for any damage caused by this script.
 Starboy is intented ONLY FOR EDUCATIONAL PURPOSES!!! STAY LEGAL!!! 
 

# How to install:
 
cd Starboy

bash installer.sh