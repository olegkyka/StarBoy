chmod +x starboy
cp -r starboy /usr/local/sbin
echo "rm -rf /usr/local/sbin/starboy && echo -e '\e[1;31m    

                       (UNINSTALLATION COMPLETED)

\e[0m' && rm uninstaller.sh " > uninstaller.sh 



echo -e '\e[1;33m



      _/?\_                                                                   
     (҂`_´)                                                                  
     <,︻╦╤─ ҉ - - - - - - - - - - - - - - - - - - - - - - - - - - - -514437     
     _/-\_  \e[1;34m
                                
                                Created by "Lennis the don"
                                 \e[1;31m


 Usage of StarBoy for attacking targets without prior mutual consent is
 ILLEGAL. The Developer is not responsible for any damage caused by this script.
 Starboy is intented ONLY FOR EDUCATIONAL PURPOSES!!! STAY LEGAL!!!
  
\e[1;36m
                      
                       (INSTALLATION COMPLETED)

                                                             \e[1;32m

  To execute StarBoy type anywhere in your terminal "starboy".  \e[0m 
'















 
